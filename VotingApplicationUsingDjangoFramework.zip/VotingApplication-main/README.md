# VotingApplication
voting web application using django framework by Apshana
